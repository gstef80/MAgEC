from . import runner

def main():
    runner.run()


if __name__ == '__main__':
    main()
